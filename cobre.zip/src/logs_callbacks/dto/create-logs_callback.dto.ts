export class CreateLogsCallbackDto {}
