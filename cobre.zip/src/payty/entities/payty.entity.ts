export class Payty {}
