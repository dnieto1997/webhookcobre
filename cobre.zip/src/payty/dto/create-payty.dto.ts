export class CreatePaytyDto {}
