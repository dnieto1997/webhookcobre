export class CreateAliadoDto {}
